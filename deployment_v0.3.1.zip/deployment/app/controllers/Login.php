<?php

class Login extends Controller
{
  public function index()
  {
    $errors = [];
    $user = new User();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

      $email = $_POST['email'] ?? '';
      $password = $_POST['password'] ?? '';

      $arr['email'] = $email;
      $row = $user->first($arr);

      if ($row && password_verify($password, $row->password)) {

        // Store user in session
        Auth::authenticate($row);

        // Redirect based on role
        switch ($row->role) {
          case 'admin':
            redirect('admin/dashboard');
            break;
          case 'dorm':
            redirect('dorm/dashboard');
            break;
          case 'user':
            redirect('explore'); // or 'profile' if you want
            break;
          default:
            $errors['errors'] = 'Unrecognized role. Contact admin.';
        }

      } else {
        $errors['errors'] = 'Email or Password is invalid';
      }
    }

    $this->view('login', [
      'errors' => $errors
    ]);
  }
}
