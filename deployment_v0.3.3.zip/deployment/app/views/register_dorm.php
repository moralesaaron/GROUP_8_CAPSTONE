<?php include "partials/header.php" ?>

<body>
    <div class="container">
        
    <form method="POST" action="/register_dorm">
        <input type="text" name="dorm_name" required>
        <input type="email" name="email" required>
        <input type="password" name="password" required>
        <input type="hidden" name="role" value="dorm">
        <button type="submit">Register Dorm</button>
    </form>




    </div>
</body>



<?php include "partials/footer.php" ?>