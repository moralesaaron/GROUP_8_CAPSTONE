<?php include "partials/header.php" ?>

<body>
    <div class="container">
        
        <form method="POST" action="/register_user">
            <input type="text" name="firstname" required>
            <input type="text" name="lastname" required>
            <input type="email" name="email" required>
            <input type="password" name="password" required>
            <input type="hidden" name="role" value="user">
            <button type="submit">Register</button>
        </form>



    </div>
</body>



<?php include "partials/footer.php" ?>