<?php include "partials/header.php" ?>

<body>
    <!-- Navbar -->
    
    
    <!-- main content -->
    <div class="container hero-section">
        <div class="row w-100 align-items-center mb-5">
            <!-- Main Content -->
            <div class="col-md-6">
                <h1 class="display-3 fw-bold">
                LOGIN</h1>
                <!-- <img src="<?= ROOT ?>/assets/images/logo.png" alt="Visual representation" class="img-fluid w-100" /> -->
                
                <!-- <div class="mt-4">
                    <a href="#" class="custom-button text-white me-3">Get started</a>
                    <a href="#" class="btn btn-outline-secondary">Talk to a human</a>
                </div> -->
            </div>
            
            <!-- Search Bar -->
            
            <div class="col-md-6 d-flex justify-content-center">
            <form action="" method="POST" class="w-50 mx-auto">
    <!-- <h2 class="login-title">Login</h2> -->

    <?php if (!empty($errors)): ?>

      <div class="alert alert-warning alert-dismissible fade show" role="alert">

        <?php foreach ($errors as $error): ?>
          <?= $error . "<br>" ?>
        <?php endforeach; ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>

              <?php endif; ?>

              <div class="mb-2">
                <label for="">Email</label>
                <input type="text" value="<?= get_var('email') ?>" name="email" class="form-control">
              </div>
              <div class="mb-2">
                <label for="">Password</label>
                <input type="password" name="password" class="form-control">
              </div>
              <button type="submit" class="custom-button text-white me-3">Login</button>
              
                    <br><br><br><br><br>
                    No account yet?<br> <a href="<?= ROOT ?>/register_user" class="btn btn-dark">Register Here</a>

            </form>
            </div>
            </div>


            


        </div>
    </div>

</body>



<?php include "partials/footer.php" ?>