<?php

class RegisterDorm extends Controller
{
  public function index()
  {
    $errors = [];
    $user = new User();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $_POST['role'] = 'dorm'; // Hardcode role
      $_POST['token'] = random_string(60);
      $_POST['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);

      if ($user->validate($_POST)) {
        $user->insert($_POST);
        redirect('login');
      } else {
        $errors = $user->errors;
      }
    }

    $this->view('register_dorm', ['errors' => $errors]);
  }
}
