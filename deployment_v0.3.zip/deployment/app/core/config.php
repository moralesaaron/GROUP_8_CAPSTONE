<?php

define('ROOT', 'http://localhost/group_8_capstone/deployment/public');
define('PATH', 'C:/xampp/htdocs/GROUP_8_CAPSTONE/deployment/app/views/');
//define('APP_NAME', 'comLAB');


define('DB_HOST', 'localhost');
define('DB_NAME', 'doli_db');
define('DB_USER', 'root');
define('DB_PASS', '');
